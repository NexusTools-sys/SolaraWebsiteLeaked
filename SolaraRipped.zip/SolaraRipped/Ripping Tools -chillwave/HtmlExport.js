(async function exportPage() {
    const script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.7.1/jszip.min.js';
    document.head.appendChild(script);
    await new Promise(resolve => script.onload = resolve);

    const zip = new JSZip();

    let htmlContent = document.documentElement.outerHTML;

    const stylesheets = Array.from(document.styleSheets)
        .map((sheet) => {
            try {
                const rules = Array.from(sheet.cssRules).map(rule => rule.cssText).join('\n');
                return `/* From: ${sheet.href || 'inline'} */\n${rules}`;
            } catch (e) {
                console.warn('Access to stylesheet %s is blocked due to CORS policy', sheet.href);
                return '';
            }
        })
        .join('\n\n');

    const inlineScripts = Array.from(document.scripts)
        .filter(script => script.src === '')
        .map(script => script.textContent)
        .join('\n\n');

    const scriptPromises = Array.from(document.scripts)
        .filter(script => script.src)
        .map(async (script, index) => {
            try {
                const response = await fetch(script.src);
                const scriptText = await response.text();
                const fileName = `script${index}.js`;
                script.src = fileName; 
                zip.file(fileName, scriptText);
            } catch (e) {
                console.warn('Failed to fetch script:', script.src);
            }
        });

    const imagePromises = Array.from(document.images).map(async (img, index) => {
        try {
            const response = await fetch(img.src);
            const blob = await response.blob();
            const extension = img.src.split('.').pop().split('?')[0];
            const fileName = `image${index}.${extension}`;
            img.src = fileName; 
            zip.file(fileName, blob);
        } catch (e) {
            console.warn('Failed to fetch image:', img.src);
        }
    });

    await Promise.all([...scriptPromises, ...imagePromises]);
    const updatedHtmlContent = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${document.title}</title>
    <style>
${stylesheets}
    </style>
</head>
<body>
${document.body.innerHTML}

<script>
${inlineScripts}
</script>
</body>
</html>`;

    zip.file('index.html', updatedHtmlContent);
    zip.generateAsync({ type: 'blob' }).then((content) => {
        const a = document.createElement('a');
        a.href = URL.createObjectURL(content);
        a.download = 'exported_page.zip';
        a.click();
    });
})();
